module deneme {
	requires java.sql;
}