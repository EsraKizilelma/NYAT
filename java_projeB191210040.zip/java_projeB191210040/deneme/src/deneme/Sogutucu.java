package deneme;

public class Sogutucu implements ISogutucu {

    private boolean sogutucuDurum = false;

    @Override
    public void sogutucuKapat() {
        System.out.println("Sogutucu kapatildi ...");
        sogutucuDurum = false;
    }
    @Override
    public boolean sogutucuDurum() {
        return sogutucuDurum;
    }
    @Override
    public void sogutucuAc(IAlgilayici algilayici) {
        if(algilayici.degerGetir() == null)
            System.out.println("Hen�z �lc�m yapilmamis, algiyaciyi calistirin..");
        else{
            if(algilayici.degerGetir() <15)
                System.out.println("Yeterli sogutma saglandi..");
            else{
                algilayici.yeniDeger(algilayici.degerGetir() - 5);
                System.out.printf("Sogutucu calistirildi.. Yeni sicaklik degeri %.2f Derece\n",algilayici.degerGetir());
                sogutucuDurum = true;
            }
        }
    }
}
