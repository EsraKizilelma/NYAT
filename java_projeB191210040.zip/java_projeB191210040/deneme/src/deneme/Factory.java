package deneme;

public class Factory {
  public static IAlgilayici algilayici(){return  new Algilayici();}
  public static ISogutucu sogutucu(){return new Sogutucu();}
  public static IEkran ekran(){return new Ekran();}
 
}


