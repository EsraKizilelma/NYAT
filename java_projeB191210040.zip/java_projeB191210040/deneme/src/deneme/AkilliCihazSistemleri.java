package deneme;

import java.sql.*;

public class AkilliCihazSistemleri {
    public static void main(String[] args) throws SQLException, InterruptedException {
        AkilliCihaz akilliCihaz = new AkilliCihaz(
                new Ekran(),
                new Algilayici(),
                new Sogutucu(),
                new Observer(),
                new PostgresSQLSurucu());

        akilliCihaz.basla();
    }
}