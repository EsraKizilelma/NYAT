package deneme;

public class Ekran implements IEkran {
    @Override
    public void menu(String username) {
        System.out.println("\n~~AKILLI CIHAZ SISTEM�~~");
        System.out.println("Kullanici: "+username);
        System.out.println("1- S�cakl�k Algila");
        System.out.println("2- Sogutucuyu Ac");
        System.out.println("3- Sogutucuyu Kapat");
        System.out.println("4- Sicaklik Degeri Uyaricisini �al��t�r");
        System.out.println("5- Sicaklik Degeri Uyaricisini Kapat");
        
        System.out.println("6- Cikis");
        System.out.print("Seciminizi giriniz : ");
    }

    @Override
    public void girisMesaj() {
        System.out.println("\n~~AKILLI CIHAZ SISTEM�~~");
        System.out.println("Hosgeldiniz");
        System.out.println("Sisteme giris yapiniz...");
    }

    @Override
    public void girisYuklenme() throws InterruptedException {
    	 System.out.println("�nternete ba�lan�yor...");
    	 Thread.sleep(1000);         
         System.out.println("Dogrulama basarili...");
         System.out.println("Giris Yapiliyor...");
        Thread.sleep(400);
       
    }

    @Override
    public void cikisYuklenme() throws InterruptedException {
        System.out.println("Cikis Yapiliyor...");
        Thread.sleep(400);
     
    }

    @Override
    public void olculenDeger( double deger){

            System.out.printf("Olculen deger %.2f ",deger);
    }

    @Override
    public void anaMenuyeDonusMesaj() throws InterruptedException {
        Thread.sleep(400);
        System.out.println("Hatali giris yaptiniz, ana men�ye d�nd�r�l�yorsunuz.");
        Thread.sleep(400);
      
    }
}