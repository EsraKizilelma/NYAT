package deneme;

abstract class KontrolcuMesajcisi {
    static String yuksekSicaklikUyari(){
        return "Sicaklik cok y�ksek, sogutucuyu calistirin.";
    }
    static String dusukSicaklikUyari(){
        return "Sicaklik cok d�s�k...";
    }
    static String dengeliSicaklikUyari() {
        return "Sicaklik dengeli...";
    }
}