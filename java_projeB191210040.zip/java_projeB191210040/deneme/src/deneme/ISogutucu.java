package deneme;

public interface ISogutucu {
	   boolean sogutucuDurum();
       void sogutucuKapat();
       void sogutucuAc(IAlgilayici algilayici);
}
