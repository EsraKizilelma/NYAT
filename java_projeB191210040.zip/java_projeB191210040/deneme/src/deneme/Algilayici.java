package deneme;

import java.util.Random;

public class Algilayici extends SicaklikKontrolcu implements IAlgilayici{
    private Double value = null;
    private static Boolean kontrolcuDurum = false;

    @Override
    public void otoKontrolAktif(){

        if(kontrolcuDurumu())
            System.out.println("Uyarici zaten acik");
        else{
            System.out.println("Uyarici acildi");
            guncelleKontrolcuDurumu(true);
        }
    }

    @Override
    public void otoKontrolPasif(){
        if(!kontrolcuDurumu())
            System.out.println("Uyarici zaten kapali");
        else{
            System.out.println("Uyarici kapatildi");
            guncelleKontrolcuDurumu(false);
        }
    }

    @Override
    public void algila() throws InterruptedException {
        System.out.println("Sicaklik olculuyor...");
        Thread.sleep(400);
    }

    @Override
    public double olc() {
        Random rnd = new Random();
        double minOlcum = 15;
        double maxOlcum = 45;
        value = minOlcum + (maxOlcum - minOlcum) * rnd.nextDouble();
        return value;
    }

    @Override
    public Double degerGetir(){
        return value;
    }

    @Override
    public void yeniDeger(Double yeniDeger){
        value = yeniDeger;
    }

    @Override
    public void sicaklikOtoKontrol(){
        if(degerGetir() > 32)
            bilgilendirYuksekSicaklik();
        else if(degerGetir()<10)
            bilgilendirDusukSicaklik();
        else
            bilgilendirDengeliSicaklik();
    }

    @Override
    public boolean kontrolcuDurumu(){
        return kontrolcuDurum;
    }

    public void guncelleKontrolcuDurumu(Boolean yeniDurum){
        kontrolcuDurum = yeniDurum;
    }
}
