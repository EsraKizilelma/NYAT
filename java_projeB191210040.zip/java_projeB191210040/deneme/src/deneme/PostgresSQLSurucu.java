package deneme;
import java.sql.*;

public class PostgresSQLSurucu implements IveritabaniSurucu {
	    Connection conn;
	    ResultSet rs;
	    Statement stmt;
	    boolean state;
	    boolean role;
		@Override
		public void baglan() {
			 try{
		            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/yenidb","postgres", "206623");
		        }
		        catch (Exception e){
		            e.printStackTrace();
		        }
			
		}
		@Override
		public boolean sistemeGiris(String username, String password) {
			 try{
		            String girisKontrol = "SELECT *  FROM \"kullanici\" WHERE \"username\"='" + username + "' and \"password\"='" + password + "'";
		            stmt = conn.createStatement();
		            rs = stmt.executeQuery(girisKontrol);
		            if(!rs.next())
		                state = false;
		            else{
		                state = true;
		            }
		            return state;
		        }
		        catch (Exception e){
		            e.printStackTrace();
		            return false;
		        }
		}
		@Override
		public void baglantiSonlandir() throws SQLException {
			 conn.close();
		        stmt.close();
		        rs.close();
			
		}
		@Override
		public boolean yetkiKontrol(String username, String password) throws SQLException {
		     String yetkiKontrol = "SELECT \"role_id\" FROM \"kullanici\" WHERE \"username\"='" + username + "' and \"password\"='" + password + "'";
		        stmt = conn.createStatement();
		        rs = stmt.executeQuery(yetkiKontrol);
		        rs.next();
		        role = rs.getString(1).equals("1");
		        return role;
		    }
		}
	    


