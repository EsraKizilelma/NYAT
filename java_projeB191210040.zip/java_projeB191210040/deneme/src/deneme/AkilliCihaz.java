package deneme;

import java.sql.SQLException;
import java.util.Scanner;

public class AkilliCihaz implements IAkilliCihaz{
    private  IEkran ekran=Factory.ekran() ;
    private  ISogutucu sogutucu=Factory.sogutucu();
    private  IAlgilayici algilayici=Factory.algilayici();
    private  IveritabaniSurucu veritabaniSurucu ;
    private  IObserver izleyici;
    private final VeritabaniIslemleri veritabaniIslemleri;

    private static final int SICAKLIK_GORUNTULE = 1;
    private static final int SOGUTUCUYU_AC = 2;
    private static final int SOGUTUCUYU_KAPAT = 3;
    private static final int OTO_SICAKLIK_KONTROL_ACIK = 4;
    private static final int OTO_SICAKLIK_KONTROL_KAPALI = 5;
    private static final int CIKIS = 6;

    public AkilliCihaz(IEkran ekran, IAlgilayici algilayici, ISogutucu sogutucu, IObserver izleyici, IveritabaniSurucu veritabaniSurucu){
        this.ekran = ekran;
        this.algilayici = algilayici;
        this.sogutucu = sogutucu;
        this.izleyici = izleyici;
        this.veritabaniSurucu = veritabaniSurucu;
        veritabaniIslemleri = new VeritabaniIslemleri(veritabaniSurucu);
        algilayici.addObserver(izleyici);
    }
    @Override
    public void basla() throws InterruptedException, SQLException {
        ekran.girisMesaj();
        Scanner input = new Scanner(System.in);
        int sayac = 2;
        while(sayac>-1){
            System.out.print("Kullan�c� Ad� Giriniz : ");
            String kullaniciAdi = input.nextLine();
            System.out.print("�ifre Giriniz : ");
            String kullaniciSifre = input.nextLine();
            veritabaniIslemleri.baglanDB();
            if(veritabaniIslemleri.girisKontrol(kullaniciAdi,kullaniciSifre)){
                ekran.girisYuklenme();
                int secim;
                do{
                    ekran.menu(kullaniciAdi);
                    secim = input.nextInt();
                    if(veritabaniIslemleri.yetkiKontrol(kullaniciAdi,kullaniciSifre) || secim == CIKIS ){
                        switch (secim) {
                        case SICAKLIK_GORUNTULE:  
                            if(true){
                                algilayici.algila();
                                double olcum = algilayici.olc();
                               
                                if(algilayici.kontrolcuDurumu()){
                                 ekran.olculenDeger(olcum);
                                    algilayici.sicaklikOtoKontrol();
                                }
                               else
                                	
                                    ekran.olculenDeger(olcum);
                            }
                         
                            break;
                            case SOGUTUCUYU_AC:
                                sogutucu.sogutucuAc(algilayici);
                                break;
                            case SOGUTUCUYU_KAPAT:
                                if(sogutucu.sogutucuDurum())
                                    sogutucu.sogutucuKapat();
                                else
                                   System.out.println("Sogutucu zaten kapali...");
                                break;
                            case OTO_SICAKLIK_KONTROL_ACIK:
                                algilayici.otoKontrolAktif();
                                algilayici.sicaklikOtoKontrol();
                                break;
                            case OTO_SICAKLIK_KONTROL_KAPALI:
                                algilayici.otoKontrolPasif();    
                                algilayici.sicaklikOtoKontrol();
                                break;
                            case CIKIS:
                                veritabaniIslemleri.baglantiSonlandir();
                                ekran.cikisYuklenme();
                                System.exit(0);
                                break;
                            default:
                                System.out.println("1-6 aras�nda bir say� girmelisiniz");
                        }
                    }
                    else
                        System.out.println("Bu kullanicinin yetkisi yoktur...");

                }while(true);
            }
            else
            {
                System.out.println("Girilen bilgilere ait kullanici bulunmamaktad�r.");
                if(sayac != 0)
                    System.out.println("Kalan deneme hakkiniz "+sayac);
                else
                    System.out.println("Deneme hakkiniz kalmadi...");
                sayac--;
            }
        }
    }
}
