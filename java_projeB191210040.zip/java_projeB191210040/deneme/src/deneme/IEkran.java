package deneme;

public interface IEkran {
	 	void menu(String username);
	    void girisMesaj();
	    void girisYuklenme() throws InterruptedException;
	    void cikisYuklenme() throws InterruptedException;	
	    void olculenDeger(double deger);
	    void anaMenuyeDonusMesaj() throws InterruptedException;
}
