package deneme;

public interface IObserver {
	   void kullanicilariBilgilendir(String mesaj);
}


