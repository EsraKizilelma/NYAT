package deneme;

import java.sql.SQLException;

public interface IAkilliCihaz {
	public void basla() throws InterruptedException, SQLException;
	
}
